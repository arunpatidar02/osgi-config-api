$(document).ready(function () {
    
    var path = "/bin/api/osgiconfig.json";
    $.ajax({
        url: path + "&ck=" + Math.random(),
        type: "GET",
        dataType: "text json",
        beforeSend: function () {
            $("tfoot").removeClass('granite-collection-loading-title');
        },
        complete: function () {
            $("tfoot").addClass('granite-collection-loading-title');
        },
        success: function (data) {
            var item = '';
            var dialogCollection = [];
            for (var i in data) {
                var c = Number(i) + 1;
                var pid = data[i].pid;
                var fid = data[i].factoryPid;
                var changeCount = data[i].changeCount;
                var repoPaths = "";
                var isRepo = "No"
                if (typeof data[i].repositoryPaths !== 'undefined') {
                    repoPaths = data[i].repositoryPaths.toString();
                    isRepo = "Yes"
                }
                var prop = data[i].properties;
                
                var propData = "";
                for (var p in prop) {
                    propData = propData + '|' + p + '|' + HTMLEncode(prop[p].toString()) + '|';
                }
                
                var propStr = '<div class="properties">';
                var propTableStart = '<table><thead><tr><th>Attribute</th><th>values</th></tr></thead><tbody>';
                var propTableEnd = '</tbody></table>';
                var propTableRow = '';
                
                for (var j in prop) {
                    propTableRow = propTableRow + '<tr><td>' + j + '</td><td>';
                    if (typeof prop[j] === 'object') {
                        for (var o in prop[j]) {
                            propTableRow = propTableRow + '<span>' + HTMLEncode(prop[j][o].toString()) + '</span>';
                        }
                    } else {
                        propTableRow = propTableRow + '<span>' + HTMLEncode(prop[j].toString()) + '</span>';
                    }
                    propTableRow = propTableRow + '</td></tr>';
                }
                if (propTableRow != '') {
                    propStr = propStr + propTableStart + propTableRow + propTableEnd;
                }
                propStr = propStr + '</div>';
                
                var popupStr = '<div class="popup pid"><span>Pid</span>' + pid + '</div>';
                if (typeof fid !== "undefined") {
                    popupStr = popupStr + '<div class="popup fid"><span>factoryPid</span>' + fid + '</div>';
                }
                popupStr = popupStr + '<div class="popup fid"><span>Change Count</span>' + changeCount + '</div>';
                if (repoPaths !== "") {
                    popupStr = popupStr + '<div class="popup repopath"><span>Repostiory Paths</span>' + repoPaths + '</div>';
                }
                popupStr = popupStr + '<div class="popup prop"><div>Properties</div>' + propStr + '</div>';
                
                // row item
                item = item + '<tr class="coral-Table-row" is="coral-table-row" role="row" aria-selected="false">' +
                    '<td is="coral-table-cell" alignment="center"  role="gridcell" aria-selected="false">' + c + '</td>' +
                    '<td is="coral-table-cell" alignment="center"  role="gridcell" aria-selected="false">' + pid + '</td>' +
                    '<td is="coral-table-cell" alignment="center"  role="gridcell" aria-selected="false">' + isRepo + '</td>' +
                    '<td is="coral-table-cell" alignment="center" class="config-navigator" role="gridcell" aria-selected="false">' +
                    ' <coral-icon icon="viewDetail" class="foundation-collection-item-thumbnail coral3-Icon coral3-Icon--viewDetail coral3-Icon--sizeS util-config-more-open" size="S" role="img" aria-label="view detail" data-item="item' + i + '"></coral-icon>' +
                    ' <div class="hide">' + propData + '</div>' +
                    ' </td>' +
                    '</tr>';
                
                
                var dialog = new Coral.Dialog();
                dialog.id = 'item' + i;
                dialog.header.innerHTML = '<coral-alert-header>configuration details</coral-alert-header>';
                dialog.content.innerHTML = '<coral-alert-content><div class="content">' + popupStr + '</div></coral-alert-content>';
                dialog.footer.innerHTML = '<button is="coral-button" variant="primary" class="util-config-more-close" data-item="item' + i + '"><coral-button-label>Close</coral-button-label></button>';
                dialog.variant = "info";
                
                dialogCollection.push(dialog);
            }
            
            $("#utils-config-list tbody").find('tr').remove();
            $("#utils-config-list tbody").html(item);
            dialogCollection.forEach(function (dialog) {
                document.body.appendChild(dialog);
            });
        }
    });
    
    
    function HTMLEncode(s) {
        return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;').replace(/>/g, '&gt;').replace(/'/g, '&apos;');
    }
    
    $(document).on("click", ".config-navigator", function () {
        var activeItem = '#' + $(this).find(".util-config-more-open").data("item");
        $(activeItem).addClass("is-open");
        $(activeItem).css({
            "display": "block",
            "z-index": "10020"
        });
        $('<div class="coral3-Backdrop is-open" aria-hidden="true" style="z-index: 10019;"></div>').appendTo("body");
    });
    
    $(document).on("click", ".util-config-more-close", function () {
        $(".coral3-Backdrop").remove();
        var activeItem = '#' + $(this).data("item");
        $(activeItem).removeClass("is-open");
        $(activeItem).css({
            "display": "none",
            "z-index": "0"
        });
    });
    
    $(document).on("keyup", "#utils-config-search-text", function () {
        applyFilter($(this).val().toLowerCase(), $("#utils-config-search-select").val().toLowerCase());
    });
    
    $(document).on("change", "#utils-config-search-select", function () {
        applyFilter($("#utils-config-search-text").val().toLowerCase(), $(this).val().toLowerCase());
    });
    
    //open search panel on load
    setTimeout(() => {
            $('coral-cyclebutton .coral3-Icon--chevronDown').click();
            $('coral-cyclebutton coral-overlay coral-selectlist-item:nth-child(2)').click();
        },
        1000);
    
    function applyFilter(txtVal, filterVal) {
        $("#utils-config-list table tbody tr").filter(function () {
            $(this).toggle($(this).text().toLowerCase().indexOf(txtVal) > -1)
        });
        
        if (filterVal == "repo") {
            $("#utils-config-list table tbody tr").filter(function () {
                $(this).toggle($(this).find("td").eq(2).text() == "Yes" && $(this).text().toLowerCase().indexOf(txtVal) > -1)
            });
        }
    }
    
});